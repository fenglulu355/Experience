<template>
  <div class="navgation">
    <div class="navtop">
      <div class="logo">
        <div class="logopic">
          <img src="../assets/navgetion/LOGO.png" @click="tohome" alt />
        </div>
      </div>
      <div class="search">
        <input type="text" @blur="toSerach" placeholder="请输入产品关键词" v-model="search" />
        <div
          @click="toSerach"
          class="searchimg"
          :style="{backgroundImage: 'url(' + require('../assets/navgetion/search.png')+ ')',
             backgroundSize:'cover',
            backgroundRepeat: 'no-repeat',
            backgroundPosition:'center'
            }"
        ></div>
      </div>
      <div class="nav-right">
        <div
          @click="nav=!nav"
          class="icon"
          :style="{backgroundImage: 'url(' + require('../assets/navgetion/nav.png')+ ')',
             backgroundSize:'cover',
            backgroundRepeat: 'no-repeat',
            backgroundPosition:'center'
            }"
        ></div>
      </div>
    </div>
    <div class="nav" v-show="nav">
      <ul class="navlist">
        <li class="navli"
        @click="toNav(index)"
         v-for="(item, index) in navlist" :key="index">
          <router-link :to="item.path">
            <span>{{item.name}}</span>
          </router-link>
        </li>
      </ul>
      <div class="none" @click="nav=!nav"></div>
    </div>
  </div>
</template>

<script>
import httpUrl from "../utils/url";
let timer = null; //定义初始值
export default {
  name: "navgation",
  data() {
    return {
      nav: false,
      trans: false,
      search: "",
      news: false,
      res: [],
      proClass: 0,
      baseurl: "",
      activeClass: 0,
      selClass: 0,
      navlist: [
        { name: "首页", path: "/" },
        { name: "长湖产品", path: "/product" },
        { name: "长湖案例", path: "/cases" },
        { name: "关于长湖", path: "/about" },
        { name: "新闻动态", path: "/news" },
        { name: "联系我们", path: "/contact" }
      ],

      scrolldis: "",
      searchRes: "",
      webinfo: []
    };
  },
  created() {
    this.requstNews();
    this.requstWeb();
    this.baseurl = httpUrl.httpUrl;
    if (!sessionStorage.getItem("curindex")) {
      this.activeClass = 0;
    } else {
      this.activeClass = sessionStorage.getItem("curindex");
    }
    //
  },
  methods: {
    toSerach() {
      // 正则表达式判断，只能输入中文、数字、英文字符
      let pattern = /^[\u4E00-\u9FA5A-Za-z0-9]+|$ /,
        searchInfo = pattern.test(this.search);
      if (this.search == "") {
        alert("输入值为空");
      } else {
        if (searchInfo == true) {
          this.$axios
            .post("/index/api/getProductList", {
              keyword: this.search
            })
            .then(res => {
              // 判断是否有内容
              this.searchRes = res.data.data.data[0];
              if (res.data.data.data.length == 0) {
                alert("您搜索的内容不存在");
              } else {
                // console.log(this.search,'aaaaaa')
                // let id = this.searchRes.article_id;
                this.$router.push({
                  path: "/searchs",
                  query: { search: this.search }
                });
                this.$router.go(0);
              }
            });
        } else {
          alert("只能输入中文、数字、英文字符");
        }
      }
    },
    mouseenter(index) {
      if (index == 4) {
        this.news = true;
      } else {
        this.news = false;
      }
    },
    requstNews() {
      this.$axios.post("/index/api/getNewsClass").then(resa => {
        this.res = resa.data.data;
      });
    },
    requstWeb() {
      this.$axios.post("/index/api/web_config").then(res => {
        this.webinfo = res.data.data;
        // console.log(this.webinfo, "  this.webinfo ");
      });
    },
    tohome() {
      this.$router.push({
        path: "/"
      });
      sessionStorage.setItem("curindex", 0);
      this.activeClass = sessionStorage.getItem("curindex");
      sessionStorage.setItem("selindex", 0);
      this.selClass = sessionStorage.getItem("selindex");
    },
    toNav(index) {
      sessionStorage.setItem("curindex", index);
      this.activeClass = sessionStorage.getItem("curindex");
       setTimeout(() => {
        this.nav = false;
      }, 200);
    }
  }
};
</script>
<style lang="less" scoped>
.navgation {
  width: 100%;
  height: 88px;
  background: #012c1c;
  position: relative;
  .navtop {
    display: flex;
    // justify-content: space-between;
    box-sizing: border-box;
    padding: 0 1%;
    .logo {
      width: 224px;
      box-sizing: border-box;
      .logopic {
        width: 224px;
        height: 88px;
        display: flex;
        justify-content: center;
        align-items: center;
        img {
          max-width: 100%;
          max-height: 100%;
        }
      }
    }
    .search {
      width: 340px;
      line-height: 88px;
      position: relative;
      input {
        box-sizing: border-box;
        border: 1px solid #dde0df;
        background: white;
        width: 255px;
        height: 46px;
        border-radius: 25px;
        padding-left: 50px;
        color: #999999;
        &::placeholder {
          color: #999999;
          font-size: 24px;
        }
      }
      .searchimg {
        width: 24px;
        height: 24px;
        position: absolute;
        top: 50%;
        transform: translateY(-50%);
        left: 10px;
      }
    }

    .nav-right {
      width: calc(100% - 570px);
      position: relative;
      height: 88px;
      .icon {
        position: absolute;
        top: 50%;
        transform: translateY(-50%);
        right: 0;
        width: 56px;
        height: 56px;
      }
      .navlist {
        box-sizing: border-box;
        width: 80%;
        display: grid;
        grid-template-columns: repeat(6, 1fr);
        height: 80px;
        justify-items: end;

        .navli {
          display: inline-block;
          width: 100%;
          height: 80px;
          text-align: center;
          padding-left: 2%;
          .navitem {
            margin-top: 20px;
            width: 100%;
            a {
              display: inline-block;
              height: 100%;
              width: 100%;
              line-height: 40px;
              color: white;
            }
          }
          .show {
            width: 100%;
            height: 40px;
            background: #82c41c;
          }
        }
      }
      .newsbox {
        cursor: pointer;
        width: 14%;
        position: absolute;
        top: 80px;
        right: 13%;
        background: #111111;
        color: #ffffff;
        font-size: 14px;
        .newslist {
          width: 100%;
          .newslibox {
            box-sizing: border-box;
            width: 100%;
            height: 40px;
            line-height: 40px;
            text-align: center;
            p {
              width: 100%;
              overflow: hidden;
              white-space: nowrap;
              text-overflow: ellipsis;
            }
          }
        }
        .sel {
          background: #333333;
        }
      }
    }
  }
  .nav {
    position: fixed;
    z-index: 111;
    top: 88px;
    right: 0;
    width: 100%;
    .navlist {
      width: 100%;
      height: 360px;
      .navli {
        text-align: center;
        background: #82c41c;
        border-bottom: 1px solid white;
        a {
          display: inline-block;
          height: 60px;
          line-height: 60px;
          color: #ffffff;
        }
      }
    }
    .none {
      width: 100%;
      opacity: 0;
      height: 900px;
    }
  }
}
</style>